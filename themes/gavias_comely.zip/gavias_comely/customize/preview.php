<?php 
require('fonts.php');
print gavias_comely_links_typography_font($json);
require('dynamic_style.php');